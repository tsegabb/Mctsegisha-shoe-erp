import { z } from 'zod';

export const pagingQuery = {
  page: z.coerce.number().int().min(1).max(100_000).optional(),
  limit: z.coerce.number().int().min(1).max(200).optional(),
};

const UNPAGED_CAP = 1000; // legacy callers that send neither page nor limit still get a bounded array

export interface Paging {
  paged: boolean;
  page: number;
  limit: number;
  offset: number;
}

export function resolvePaging(q: { page?: number; limit?: number }): Paging {
  const paged = q.page !== undefined || q.limit !== undefined;
  const limit = paged ? (q.limit ?? 50) : UNPAGED_CAP;
  const page = q.page ?? 1;
  return { paged, page, limit, offset: (page - 1) * limit };
}

/** Paged callers get an envelope; legacy callers get the plain array (same as before). */
export function pageResult<T>(rows: T[], total: number, p: Paging) {
  if (!p.paged) return rows;
  return { data: rows, total, page: p.page, limit: p.limit, totalPages: Math.max(1, Math.ceil(total / p.limit)) };
}
