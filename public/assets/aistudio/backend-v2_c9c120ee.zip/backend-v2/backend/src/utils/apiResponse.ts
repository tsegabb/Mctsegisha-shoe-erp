import type { Response } from 'express';

/** Response envelope kept compatible with the existing frontend: { success, message, data }. */
export const apiResponse = {
  success<T>(res: Response, data: T, status = 200, message = 'Operation successful') {
    return res.status(status).json({ success: true, message, data });
  },
};
