const stamp = () => new Date().toISOString();

export const logger = {
  info: (message: string, ...args: unknown[]) => console.log(`${stamp()} [INFO] ${message}`, ...args),
  warn: (message: string, ...args: unknown[]) => console.warn(`${stamp()} [WARN] ${message}`, ...args),
  error: (message: string, ...args: unknown[]) => console.error(`${stamp()} [ERROR] ${message}`, ...args),
};
