/** Collects bind values and hands back `$n` placeholders, so dynamic filters stay fully parameterised. */
export class Params {
  readonly values: unknown[] = [];
  add(value: unknown): string {
    this.values.push(value);
    return `$${this.values.length}`;
  }
}

/** Escapes LIKE wildcards in user-supplied search text (use with `ILIKE ... ESCAPE '\'`). */
export const escapeLike = (s: string) => s.replace(/[\\%_]/g, (c) => `\\${c}`);
export const likeContains = (s: string) => `%${escapeLike(s.trim())}%`;

/**
 * FROM-clause source exposing `current_stock` per variant.
 *  - no scope  -> the `variants_with_stock` view (all warehouses)
 *  - scoped    -> same shape, but stock summed over the given warehouse ids only
 * `scopeRef` is a placeholder such as "$3" that is bound to a uuid[].
 */
export function variantStockSource(scopeRef?: string): string {
  if (!scopeRef) return 'variants_with_stock';
  return `(SELECT v0.*, COALESCE((SELECT SUM(ws.quantity) FROM warehouse_stock ws
                                   WHERE ws.variant_id = v0.id AND ws.warehouse_id = ANY(${scopeRef}::uuid[])), 0)::int AS current_stock
           FROM variants v0)`;
}

/** `col = ANY($n)` when scoped, otherwise a tautology. */
export const inScope = (col: string, scopeRef?: string) => (scopeRef ? `${col} = ANY(${scopeRef}::uuid[])` : 'TRUE');

/** Net-of-returns money expressions over a `sales s` alias. Profit is read, never written. */
export const NET_REVENUE = '(s.quantity * s.selling_price - s.returned_amount)';
export const NET_PROFIT = '((s.quantity * s.selling_price - s.returned_amount) - (s.quantity - s.returned_qty) * s.cost_price)';
export const COUNTED_SALE = "s.status NOT IN ('cancelled','voided')";

export const num = (v: unknown): number => (v === null || v === undefined ? 0 : Number(v));
