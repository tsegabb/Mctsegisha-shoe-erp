import crypto from 'node:crypto';

/** Short unambiguous random token for generated SKUs / order numbers. */
export const randomCode = (len = 5) =>
  crypto.randomBytes(len).toString('base64url').replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, len).padEnd(len, 'X');

export function generateSku(...parts: string[]): string {
  const clean = parts
    .map((p) => p.trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4))
    .filter(Boolean);
  return [...clean, randomCode(4)].join('-');
}

export const generateOrderNumber = () => {
  const d = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  return `PO-${d}-${randomCode(5)}`;
};

export const escapeHtml = (v: unknown) =>
  String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));
